//
//  ThirdViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class ThirdViewController: UIViewController {
    
    var timeLabel: UILabel = UILabel()
    let start = UILabel()
    var timer:Timer?
    var timeLeft = 3
    var difficulty: Int?
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(onTimerFires), userInfo: nil, repeats: true)
        
        
        let imgBackground = UIImageView()
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        let imgView = UIImageView()
        imgView.image = UIImage(imageLiteralResourceName: "Rectangle 10")
        
        
        start.frame = CGRect(x: 250, y: 300, width: 928, height: 300)
        start.text = "Let the game begin!\n Discover the culture"
        start.textColor = .black
        start.numberOfLines = 0
        start.textAlignment = .center
        
        for family in UIFont.familyNames.sorted() {
            let names = UIFont.fontNames(forFamilyName: family)
            print("Family: \(family) Font names: \(names)")
        }
        
        let myAttribute = [ NSAttributedString.Key.font: UIFont(name: "Quicksand-Bold", size: 35)! ]
        let myString = NSMutableAttributedString(string: "Let the game begin!\n", attributes: myAttribute)
        
        
        let bigFont = UIFont(name: "Quicksand-Bold", size: 40)
        let bigAtt = [NSAttributedString.Key.font : bigFont, NSAttributedString.Key.foregroundColor : UIColor.purple]
        
        myString.append(NSAttributedString(string: "Discover the culture", attributes: bigAtt as [NSAttributedString.Key : Any]))
        
        
        start.attributedText = myString
        
        
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(start)
        self.view = view
        
        imgBackground.translatesAutoresizingMaskIntoConstraints = false
        imgBackground.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        imgBackground.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.heightAnchor.constraint(equalToConstant: self.start.frame.height/1.8).isActive = true
        imgView.widthAnchor.constraint(equalToConstant: self.start.frame.width/1.8).isActive = true
        imgView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        imgView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        start.translatesAutoresizingMaskIntoConstraints = false
        start.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        start.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true

        
        
        
    }
    
    @objc func onTimerFires() {
        
        timeLeft -= 1
        timeLabel.text = "\(timeLeft) seconds left"
        
        if timeLeft <= 0 {
            timer?.invalidate()
            timer = nil
            
            DispatchQueue.main.async {
                let vc = FourthViewController(screenType: .mac, isPortrait: true)
                
                vc.timeLeft = self.difficulty
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
