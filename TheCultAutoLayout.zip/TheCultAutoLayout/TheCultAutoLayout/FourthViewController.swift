//
//  FourthViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class FourthViewController: UIViewController {
    
    var timeLabel: UILabel = UILabel()
    var timer:Timer?
    var timeLeft: Int?
    let timerLabel: UILabel = UILabel()
    let fontBold = UIFont(name: "Quicksand-Bold", size: 40)
    let fontMedium = UIFont(name: "Quicksand-Medium", size: 15)
    let buttonAnswer = UIButton()
    let buttonTip1 = UIButton()
    let buttonTip2 = UIButton()
    let buttonTip3 = UIButton()
    let buttonTip4 = UIButton()
    let buttonTip5 = UIButton()
    let buttonTip6 = UIButton()
    let answerLabel = UILabel()
    let imgBackground = UIImageView()
    let card = UIImageView()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        timerLabel.frame = CGRect(x: 675, y: 290, width: 100, height: 61)
        timerLabel.textColor = .white
        timerLabel.text = "TIMER"
        timerLabel.font = fontMedium
        
        
        answerLabel.frame = CGRect(x: 572, y: 380, width: 306, height: 158)
        answerLabel.textColor = .white
        answerLabel.text = "Know the answer?"
        answerLabel.font = fontMedium
        answerLabel.numberOfLines = 0
        answerLabel.textAlignment = .center
        
        
        timeLabel.frame = CGRect(x: 610, y: 355, width: 222, height: 61)
        timeLabel.textColor = .white
        timeLabel.font = fontBold
        timeLabel.textAlignment = .center
        
        
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(onTimerFires), userInfo: nil, repeats: true)
        
        
        imgBackground.image = UIImage(imageLiteralResourceName: "BGCLEAN")
        
        buttonAnswer.frame = CGRect(x: 570, y: 450, width: 300, height: 180)
        
        let imageAnswer = UIImage(named: "botaoResponder")!
        buttonAnswer.setImage(imageAnswer, for: .normal)
        
        buttonAnswer.addTarget(self, action: #selector(FourthViewController.touchedButtonAnswer), for: .touchUpInside)
        
        buttonTip1.frame = CGRect(x: -9, y: 628, width: 314, height: 314)
        
        buttonTip1.setTitle("Tip1", for: .normal)
        buttonTip1.titleLabel?.isHidden = true
        
        let imageButton1 = UIImage(named: "ButtonTip1")!
        buttonTip1.setImage(imageButton1, for: .normal)
        
        buttonTip1.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        buttonTip2.frame = CGRect(x: 560, y: 735, width: 329, height: 165)
        
        buttonTip2.setTitle("Tip2", for: .normal)
        buttonTip2.titleLabel?.isHidden = true
        
        let imageButton2 = UIImage(named: "ButtonTip2")!
        buttonTip2.setImage(imageButton2, for: .normal)
        
        buttonTip2.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        buttonTip3.frame = CGRect(x: 1165, y: 630, width: 329, height: 305)
        buttonTip3.setTitle("Tip3", for: .normal)
        buttonTip3.titleLabel?.isHidden = true
        
        
        let imageButton3 = UIImage(named: "ButtonTip3")!
        buttonTip3.setImage(imageButton3, for: .normal)
        
        buttonTip3.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        buttonTip4.frame = CGRect(x: 0, y: 230, width: 236, height: 290)
        buttonTip4.setTitle("Tip4", for: .normal)
        buttonTip4.titleLabel?.isHidden = true
        
        let imageButton4 = UIImage(named: "ButtonTip4")!
        buttonTip4.setImage(imageButton4, for: .normal)
        
        buttonTip4.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        buttonTip5.frame = CGRect(x: 1154, y: 230, width: 329, height: 290)
        buttonTip5.setTitle("Tip5", for: .normal)
        buttonTip5.titleLabel?.isHidden = true
        
        let imageButton5 = UIImage(named: "ButtonTip5")!
        buttonTip5.setImage(imageButton5, for: .normal)
        
        buttonTip5.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        buttonTip6.frame = CGRect(x: 335, y: -35, width: 812, height: 290)
        buttonTip6.setTitle("Tip6", for: .normal)
        buttonTip6.titleLabel?.isHidden = true
        
        let imageButton6 = UIImage(named: "ButtonTip6")!
        buttonTip6.setImage(imageButton6, for: .normal)
        
        buttonTip6.addTarget(self, action: #selector(FourthViewController.touchedTip), for: .touchUpInside)
        
        
        view.addSubview(imgBackground)
        view.addSubview(timerLabel)
        view.addSubview(timeLabel)
        view.addSubview(buttonAnswer)
        view.addSubview(answerLabel)
        view.addSubview(buttonTip1)
        view.addSubview(buttonTip2)
        view.addSubview(buttonTip3)
        view.addSubview(buttonTip4)
        view.addSubview(buttonTip5)
        view.addSubview(buttonTip6)
        
        self.view = view
        
        imgBackground.translatesAutoresizingMaskIntoConstraints = false
        imgBackground.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        imgBackground.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        timeLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: timeLabel, attribute: .centerX, relatedBy: .equal, toItem: imgBackground, attribute: .centerX, multiplier: 1, constant: 1))
        
        self.view.addConstraint(NSLayoutConstraint(item: timeLabel, attribute: .centerY, relatedBy: .equal, toItem: imgBackground, attribute: .centerY, multiplier: 0.93, constant: 1))
        
        timerLabel.translatesAutoresizingMaskIntoConstraints = false
        timerLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: timerLabel, attribute: .centerY, relatedBy: .equal, toItem: imgBackground, attribute: .centerY, multiplier: 0.75, constant: 3))
        
        answerLabel.translatesAutoresizingMaskIntoConstraints = false
        answerLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: answerLabel, attribute: .centerY, relatedBy: .equal, toItem: imgBackground, attribute: .centerY, multiplier: 1.1, constant: 1))
        
        buttonAnswer.translatesAutoresizingMaskIntoConstraints = false
        buttonAnswer.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        buttonAnswer.heightAnchor.constraint(equalToConstant: self.imgBackground.frame.height/200).isActive = true
        buttonAnswer.widthAnchor.constraint(equalToConstant: self.imgBackground.frame.width/100).isActive = true

        

          self.view.addConstraint(NSLayoutConstraint(item: buttonAnswer, attribute: .centerY, relatedBy: .equal, toItem: imgBackground, attribute: .centerY, multiplier: 1.2, constant: 1))
        
    }
    
    @IBAction func touchedButtonAnswer() {
        let vc = FifthViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func touchedTip(_ sender: UIButton) {
        let vc = SixthViewController(screenType: .mac, isPortrait: true)
        vc.button = sender.titleLabel?.text
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func onTimerFires() {
        
        timeLeft! -= 1
        timeLabel.text = "\(timeLeft!)s"
        
        if timeLeft! <= 0 {
            timer?.invalidate()
            timer = nil
            
            let vc = FifthViewController(screenType: .mac, isPortrait: true)
            navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    
    
}

