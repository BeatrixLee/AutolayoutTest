//
//  NinthViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class NinthViewController: UIViewController {
    
    let failed = UILabel()
    let buttonTry = UIButton()
    let buttonAnotherCulture2 = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        let imgBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 900))
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        let imgView = UIImageView(frame: CGRect(x: 125, y: 172, width: 1181, height: 547))
        imgView.image = UIImage(imageLiteralResourceName: "RectangleAnswer")
        
        failed.frame = CGRect(x: 250, y: 210, width: 940, height: 230)
        failed.text = "That`s okay,\n nobody is born knowing everything!"
        failed.textColor = .black
        failed.numberOfLines = 0
        failed.textAlignment = .center
        
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 0.8
        paragraphStyle.alignment = .center
        let myAttribute = [ NSAttributedString.Key.font: UIFont(name: "Quicksand-Bold", size: 100)!]
        let myString = NSMutableAttributedString(string: "That`s okay,\n", attributes: myAttribute)
        
        
        let smallFont = UIFont(name: "Quicksand-Bold", size: 65)
        let bigAtt = [NSAttributedString.Key.font : smallFont, NSAttributedString.Key.foregroundColor : UIColor.black, NSAttributedString.Key.paragraphStyle: paragraphStyle]
        
        myString.append(NSAttributedString(string: "nobody knows everything!", attributes: bigAtt as [NSAttributedString.Key : Any]))
        myString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, myString.length))
        
        
        failed.attributedText = myString
        
        let goal = UIImageView(frame: CGRect(x: 600, y: 420, width: 226, height: 226))
        goal.image = UIImage(imageLiteralResourceName: "Goal")
        
        buttonAnotherCulture2.frame = CGRect(x: 884, y: 482, width: 346, height: 145)
        
        let imageAnotherCulture2 = UIImage(named: "anotherCulture2")!
        buttonAnotherCulture2.setImage(imageAnotherCulture2, for: .normal)
        
        buttonAnotherCulture2.addTarget(self, action: #selector(NinthViewController.touchedButtonTry), for: .touchUpInside)
        
        buttonTry.frame = CGRect(x: 195, y: 482, width: 346, height: 145)
        
        let imageTry = UIImage(named: "try")!
        buttonTry.setImage(imageTry, for: .normal)
        
        buttonTry.addTarget(self, action: #selector(NinthViewController.touchedButtonAnotherCulture), for: .touchUpInside)
        
        
        
        self.view = view
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(failed)
        view.addSubview(goal)
        view.addSubview(buttonAnotherCulture2)
        view.addSubview(buttonTry)
        
    }
    
    @IBAction func touchedButtonAnotherCulture() {
        let vc = ThirdViewController(screenType: .mac, isPortrait: true)
        vc.difficulty = 120
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func touchedButtonTry() {
        let vc = FirstViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
    }
}
