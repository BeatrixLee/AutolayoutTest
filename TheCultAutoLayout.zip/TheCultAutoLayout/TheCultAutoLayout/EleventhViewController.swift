//
//  EleventhViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class EleventhViewController: UIViewController {
    
    let cultureGallery = UILabel()
    let labelCulture = UILabel()
    let backButton = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        navigationController!.pushViewController(vc, animated: true)
        navigationController?.navigationBar.isHidden = true
        
        let firework = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 285))
        firework.image = UIImage(imageLiteralResourceName: "Component 2")
        
        let china = UIImageView(frame: CGRect(x: 199, y: 373, width: 279.5, height: 395))
        china.image = UIImage(imageLiteralResourceName: "China")
        
        labelCulture.frame = CGRect(x: 577, y: 370, width: 708, height: 410)
        labelCulture.text = "China is a different country. Its strength and importance is already expressed in its name in Chinese: Zhong Guo - central country. It is a country with 4,000 years of history, with one of the largest and oldest civilizations in the world. With great symbolism linked to its culture, China shows itself as a country with a plurality of languages, crimes, ceremonies, these being crucial points in the identity construction of this civilization."
        labelCulture.numberOfLines = 0
        labelCulture.textColor = .black
        let font = UIFont(name: "Quicksand-Bold", size: 32)
        labelCulture.font = font
        
        cultureGallery.frame = CGRect(x: 250, y: 80, width: 940, height: 230)
        cultureGallery.text = "Galeria de Culturas\n Veja o que você aprendeu!"
        cultureGallery.textColor = .purple
        cultureGallery.numberOfLines = 0
        cultureGallery.textAlignment = .center
        
        backButton.frame = CGRect(x: 70, y: 79, width: 92, height: 92)
               
               let imageBackButton = UIImage(named: "back")!
               backButton.setImage(imageBackButton, for: .normal)
        
        backButton.addTarget(self, action: #selector(EleventhViewController.touchedButtonBack), for: .touchUpInside)
        
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 0.8
        paragraphStyle.alignment = .center
        let myAttribute = [ NSAttributedString.Key.font: UIFont(name: "Quicksand-Bold", size: 100)!]
        let myString = NSMutableAttributedString(string: "Culture Gallery\n", attributes: myAttribute)
        
        
        let smallFont = UIFont(name: "Quicksand-Bold", size: 80)
        let bigAtt = [NSAttributedString.Key.font : smallFont, NSAttributedString.Key.foregroundColor : UIColor.black, NSAttributedString.Key.paragraphStyle: paragraphStyle]
        
        myString.append(NSAttributedString(string: "China", attributes: bigAtt as [NSAttributedString.Key : Any]))
        myString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, myString.length))
        
        
        cultureGallery.attributedText = myString
        
        self.view = view
        view.addSubview(cultureGallery)
        view.addSubview(firework)
        view.addSubview(china)
        view.addSubview(labelCulture)
        view.addSubview(backButton)
        
    }
    @IBAction func touchedButtonBack() {
            let vc = TenthViewController(screenType: .iphone8, isPortrait: true)
            navigationController?.pushViewController(vc, animated: true)
    }
}
