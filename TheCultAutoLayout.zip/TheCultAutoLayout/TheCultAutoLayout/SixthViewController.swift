//
//  SixthViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class SixthViewController: UIViewController {
    
    var buttonBack = UIButton()
    var button: String?
    var image: UIImageView?
    
    override func loadView() {
        
        
        let view = UIView()
        view.backgroundColor = .white
        
        let imgBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 900))
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        imgBackground.isUserInteractionEnabled = true
        let tapOut = UITapGestureRecognizer(target: self, action: #selector(back))
        
        imgBackground.addGestureRecognizer(tapOut)
        
        
        image = UIImageView(frame: CGRect(x: 298, y: 51, width: 853, height: 791))
        
        
        
        
        view.addSubview(imgBackground)
        view.addSubview(image!)
        
        self.view = view
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let imagem = UIImage(named: button!)
        self.image?.image = imagem
        
    }
    
    @IBAction func back(){
        navigationController?.popViewController(animated: true)
    }
    
}
