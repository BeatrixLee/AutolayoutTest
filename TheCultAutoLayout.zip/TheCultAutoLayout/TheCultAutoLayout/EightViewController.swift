//
//  EightViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class EigthViewController: UIViewController {
    
    var congratulation = UIImage()
    let buttonEasy = UIButton()
    let buttonMedium = UIButton()
    let buttonHard = UIButton()
    let buttonAnotherCulture = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        let imgBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 900))
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        let imgView = UIImageView(frame: CGRect(x: 125, y: 172, width: 1181, height: 547))
        imgView.image = UIImage(imageLiteralResourceName: "RectangleAnswer")
        
        let firework = UIImageView(frame: CGRect(x: 91, y: 136, width: 1231, height: 207))
        firework.image = UIImage(imageLiteralResourceName: "Component 1")
        
        let congratulation = UIImageView(frame: CGRect(x: 315, y: 228, width: 800, height: 170))
        congratulation.image = UIImage(imageLiteralResourceName: "congratulation")
        
        buttonMedium.frame = CGRect(x: 779, y: 480, width: 440, height: 145)
        
        let imageMedium = UIImage(named: "medium2")!
        buttonMedium.setImage(imageMedium, for: .normal)
        
        buttonMedium.addTarget(self, action: #selector(EigthViewController.touchedButtonMedium), for: .touchUpInside)
        
        buttonAnotherCulture.frame = CGRect(x: 258, y: 480, width: 440, height: 145)
        
        let imageAnotherCulture = UIImage(named: "anotherCulture")!
        buttonAnotherCulture.setImage(imageAnotherCulture, for: .normal)
        
        buttonAnotherCulture.addTarget(self, action: #selector(EigthViewController.touchedButtonAnotherCulture), for: .touchUpInside)
        
        
        
        self.view = view
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(firework)
        view.addSubview(congratulation)
        view.addSubview(buttonMedium)
        view.addSubview(buttonAnotherCulture)
    }
    
    @IBAction func touchedButtonMedium() {
        let vc = ThirdViewController(screenType: .mac, isPortrait: true)
        vc.difficulty = 60
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func touchedButtonAnotherCulture() {
        let vc = FirstViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
}
