//
//  ViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 17/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import UIKit
import AVFoundation

class FirstViewController : UIViewController {
    
    let imgBackground = UIImageView()
    let theCult = UIImageView()
    let imgView = UIImageView()
    let buttonPlay = UIButton()
    let buttonGallery = UIButton()
    var monocle = UIImageView()
    
    override func viewDidLoad() {
        
        let view = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 1440, height: 900))
        view.backgroundColor = .white
        navigationController?.navigationBar.isHidden = true
        
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        //           let path = Bundle.main.path(forResource: "SoundTrack.mp3", ofType:nil)!
        //           let url = URL(fileURLWithPath: path)
        //
        //           var soundTrack: AVAudioPlayer?
        //
        //           do {
        //               soundTrack = try AVAudioPlayer(contentsOf: url)
        //               soundTrack?.play()
        //               soundTrack?.numberOfLoops = 3
        //           } catch {
        //               // couldn't load file :(
        //           }
        
        
        theCult.image = UIImage(imageLiteralResourceName: "theCult")
        
        
        imgView.image = UIImage(imageLiteralResourceName: "Rectangle 10")
        
        
        monocle.image = UIImage(imageLiteralResourceName: "monocle")
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            
            
            UIView.animate(withDuration: 1.8, delay: 0.3, options: .beginFromCurrentState, animations: { () -> Void in
                self.monocle.center.y = 82
                self.monocle.center.x = 393
                
            })
            
        }
        
        buttonPlay.frame = CGRect(x: 312, y: 420, width: 780, height: 140)
        
        let imagePlay = UIImage(named: "Play")!
        buttonPlay.setImage(imagePlay, for: .normal)
        
        
        buttonPlay.addTarget(self, action: #selector(FirstViewController.touchedButtonPlay), for: .touchUpInside)
        
        
        buttonGallery.frame = CGRect(x: 334, y: 550, width: 759, height: 140)
        let imageGallery = UIImage(named: "Gallery")!
        buttonGallery.setImage(imageGallery, for: .normal)
        
        
        buttonGallery.addTarget(self, action: #selector(FirstViewController.touchedButtonGallery), for: .touchUpInside)
        
        
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(buttonGallery)
        view.addSubview(buttonPlay)
        view.addSubview(theCult)
        view.addSubview(monocle)
        
        self.view = view
        
        imgBackground.translatesAutoresizingMaskIntoConstraints = false
        imgBackground.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        imgBackground.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.heightAnchor.constraint(equalToConstant: self.view.frame.height/3).isActive = true
        imgView.widthAnchor.constraint(equalToConstant: self.view.frame.width/2.5).isActive = true
        imgView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        imgView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        theCult.translatesAutoresizingMaskIntoConstraints = false
        theCult.heightAnchor.constraint(equalToConstant: self.view.frame.height/5.5).isActive = true
        theCult.widthAnchor.constraint(equalToConstant: self.view.frame.width/8).isActive = true
        theCult.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: theCult, attribute: .top, relatedBy: .equal, toItem: imgView, attribute: .top, multiplier: 1.0, constant: 0))
        
        buttonPlay.translatesAutoresizingMaskIntoConstraints = false
        buttonPlay.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        buttonPlay.heightAnchor.constraint(equalToConstant: self.view.frame.height/14).isActive = true
        buttonPlay.widthAnchor.constraint(equalToConstant: self.view.frame.width/4).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: buttonPlay, attribute: .top, relatedBy: .equal, toItem: theCult, attribute: .bottom, multiplier: 0.9, constant: 0.5))
        
        buttonGallery.translatesAutoresizingMaskIntoConstraints = false
        buttonGallery.centerXAnchor.constraint(equalTo: self.buttonPlay.centerXAnchor).isActive = true
        buttonGallery.heightAnchor.constraint(equalToConstant: self.buttonPlay.frame.height/2.2).isActive = true
        buttonGallery.widthAnchor.constraint(equalToConstant: self.buttonPlay.frame.width/2.2).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: buttonGallery, attribute: .top, relatedBy: .equal, toItem: buttonPlay, attribute: .bottom, multiplier: 1, constant: 0.5))
        
        
        monocle.translatesAutoresizingMaskIntoConstraints = false
        monocle.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        monocle.heightAnchor.constraint(equalToConstant: self.buttonGallery.frame.height/5).isActive = true
        monocle.widthAnchor.constraint(equalToConstant: self.buttonGallery.frame.width/20).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: monocle, attribute: .bottom, relatedBy: .equal, toItem: imgView, attribute: .top, multiplier: 1, constant: 0))
        self.view.addConstraint(NSLayoutConstraint(item: monocle, attribute: .left, relatedBy: .equal, toItem: view, attribute: .right, multiplier: 2, constant: 4))
        
    }
    
    @IBAction func touchedButtonPlay() {
        let vc = SecondViewController(screenType: .iphone8, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func touchedButtonGallery() {
        let vc = TenthViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
}
// Present the view controller in the Live View window


let viewController = FirstViewController()
let vc = FirstViewController(screenType: .iphone8 , isPortrait: true)
//let navigationController = UINavigationController(screenType: .iphone8 , isPortrait: true)



