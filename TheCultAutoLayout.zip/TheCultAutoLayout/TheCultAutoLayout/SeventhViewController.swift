//
//  SeventhViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class SeventhViewController: UIViewController {
    
    var timer:Timer?
    var timeLeft = 3
    var timeLabel: UILabel = UILabel()
    var congratulation = UIImage()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(onTimerFires), userInfo: nil, repeats: true)
        
        let imgBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 900))
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        let imgView = UIImageView(frame: CGRect(x: 125, y: 172, width: 1181, height: 547))
        imgView.image = UIImage(imageLiteralResourceName: "RectangleAnswer")
        
        let firework = UIImageView(frame: CGRect(x: 91, y: 136, width: 1231, height: 207))
        firework.image = UIImage(imageLiteralResourceName: "Component 1")
        
        let winner = UIImageView(frame: CGRect(x: 567, y: 399, width: 270, height: 270))
        winner.image = UIImage(imageLiteralResourceName: "Winner")
        
        let congratulation = UIImageView(frame: CGRect(x: 315, y: 228, width: 800, height: 170))
        congratulation.image = UIImage(imageLiteralResourceName: "congratulation")
        
        
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(firework)
        view.addSubview(winner)
        view.addSubview(congratulation)
        self.view = view
        
    }
    
    @objc func onTimerFires() {
        
        timeLeft -= 1
        timeLabel.text = "\(timeLeft) seconds left"
        
        if timeLeft <= 0 {
            timer?.invalidate()
            timer = nil
            
            DispatchQueue.main.async {
                let vc = EigthViewController(screenType: .mac, isPortrait: true)
                self.navigationController?.pushViewController(vc, animated: true)
                
            }
        }
    }
}
