//
//  TenthViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class TenthViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    let cultureGallery = UILabel()
    var myCollectionView: UICollectionView?
    let backButton = UIButton()
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        
        let firework = UIImageView(frame: CGRect(x: 0, y: 0, width: 1440, height: 285))
        firework.image = UIImage(imageLiteralResourceName: "Component 2")
        
        cultureGallery.frame = CGRect(x: 250, y: 50, width: 940, height: 230)
        cultureGallery.text = "Culture gallery\n see what you have learned!"
        cultureGallery.textColor = .purple
        cultureGallery.numberOfLines = 0
        cultureGallery.textAlignment = .center
        
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 0.9
        paragraphStyle.alignment = .center
        let myAttribute = [ NSAttributedString.Key.font: UIFont(name: "Quicksand-Bold", size: 100)!]
        let myString = NSMutableAttributedString(string: "Culture Gallery\n", attributes: myAttribute)
        
        
        let smallFont = UIFont(name: "Quicksand-Bold", size: 65)
        let bigAtt = [NSAttributedString.Key.font : smallFont, NSAttributedString.Key.foregroundColor : UIColor.black, NSAttributedString.Key.paragraphStyle: paragraphStyle]
        
        myString.append(NSAttributedString(string: "See what you have learned!", attributes: bigAtt as [NSAttributedString.Key : Any]))
        myString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, myString.length))
        
        backButton.frame = CGRect(x: 70, y: 79, width: 92, height: 92)
               
               let imageBackButton = UIImage(named: "back")!
               backButton.setImage(imageBackButton, for: .normal)
        
        backButton.addTarget(self, action: #selector(EleventhViewController.touchedButtonBack), for: .touchUpInside)
        
        
        cultureGallery.attributedText = myString
        
        let Layout = UICollectionViewFlowLayout()
        Layout.sectionInset = UIEdgeInsets(top: 32, left: 20, bottom: 20, right: 20)
        Layout.itemSize = CGSize(width: 226.43, height: 320)
        Layout.minimumLineSpacing = 30
        Layout.minimumInteritemSpacing = 7
        
        myCollectionView = UICollectionView(frame: CGRect(x: 120, y: 305, width: 1200, height: 595), collectionViewLayout: Layout)
        
        myCollectionView?.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "myCell")
        myCollectionView?.backgroundColor = UIColor.white
        myCollectionView?.dataSource = self
        myCollectionView?.delegate = self
        
        self.view = view
        view.addSubview(firework)
        view.addSubview(cultureGallery)
        view.addSubview(myCollectionView!)
        view.addSubview(backButton)
        
    }
    
    @IBAction func touchedButtonBack() {
    let vc = FirstViewController(screenType: .mac, isPortrait: true)
    navigationController?.pushViewController(vc, animated: true)
        
    }
    
    var cards = [Card(imageCard: "China"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio"), Card(imageCard: "Vazio")]
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cards.count
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath)
        
        myCell.backgroundView = UIImageView(image: UIImage(named: cards[indexPath.row].imageCard))
        
        return myCell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let vc = EleventhViewController(screenType: .mac, isPortrait: true)
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
