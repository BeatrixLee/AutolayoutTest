//
//  FifthViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class FifthViewController: UIViewController {
    
    let cultureLabel: UILabel = UILabel()
    let fontBold = UIFont(name: "Quicksand-Bold", size: 80)
    let button1 = UIButton()
    let button2 = UIButton()
    let button3 = UIButton()
    let button4 = UIButton()
    let imgBackground = UIImageView()
    let imgView = UIImageView()

    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        imgView.image = UIImage(imageLiteralResourceName: "RectangleAnswer")
        
        cultureLabel.frame = CGRect(x: 238, y: 210, width: 928, height: 107)
        cultureLabel.textColor = .black
        cultureLabel.text = "Whose culture is it?"
        cultureLabel.font = fontBold
        cultureLabel.textAlignment = .center
        
        button1.frame = CGRect(x: 176.8, y: 341, width: 225, height: 320)
        let imageButton1 = UIImage(named: "Japão")!
        button1.setImage(imageButton1, for: .normal)
        button1.setTitle("Japão", for: .normal)
        button1.titleLabel?.isHidden = true
        button1.addTarget(self, action: #selector(FifthViewController.wrongbutton), for: .touchUpInside)
        
        button2.frame = CGRect(x: 456.3, y: 341, width: 225, height: 320)
        let imageButton2 = UIImage(named: "Espanha")!
        button2.setImage(imageButton2, for: .normal)
        button2.setTitle("Espanha", for: .normal)
        button2.titleLabel?.isHidden = true
        button2.addTarget(self, action: #selector(FifthViewController.wrongbutton), for: .touchUpInside)
        
        
        button3.frame = CGRect(x: 735, y: 341, width: 225, height: 320)
        let imageButton3 = UIImage(named: "China")!
        button3.setImage(imageButton3, for: .normal)
        button3.setTitle("China", for: .normal)
        button3.titleLabel?.isHidden = true
        button3.addTarget(self, action: #selector(FifthViewController.rightbutton), for: .touchUpInside)
        
        button4.frame = CGRect(x: 1015.63, y: 341, width: 225, height: 320)
        let imageButton4 = UIImage(named: "Portugal")!
        button4.setImage(imageButton4, for: .normal)
        button4.setTitle("Portugal", for: .normal)
        button4.titleLabel?.isHidden = true
        button4.addTarget(self, action: #selector(FifthViewController.wrongbutton), for: .touchUpInside)
        
        
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(cultureLabel)
        view.addSubview(button1)
        view.addSubview(button2)
        view.addSubview(button3)
        view.addSubview(button4)
        self.view = view
        
        imgBackground.translatesAutoresizingMaskIntoConstraints = false
        imgBackground.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        imgBackground.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        imgView.translatesAutoresizingMaskIntoConstraints = false
//        imgView.heightAnchor.constraint(equalToConstant: self.imgBackground.frame.height).isActive = true
//        imgView.widthAnchor.constraint(equalToConstant: self.imgBackground.frame.width).isActive = true
        imgView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        imgView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        
    }
    
    @IBAction func rightbutton() {
        let vc = SeventhViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func wrongbutton() {
        let vc = NinthViewController(screenType: .mac, isPortrait: true)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
