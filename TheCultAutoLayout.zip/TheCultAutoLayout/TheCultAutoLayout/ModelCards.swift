import Foundation
import UIKit

public class Card {

    public let imageCard: String

    public init (imageCard: String) {

        self.imageCard = imageCard

    }

}
