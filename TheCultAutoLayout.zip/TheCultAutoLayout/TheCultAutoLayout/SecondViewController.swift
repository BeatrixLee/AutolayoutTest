//
//  SecondViewController.swift
//  TheCultAutoLayout
//
//  Created by Beatrix Lee on 18/08/20.
//  Copyright © 2020 Beatrix Lee. All rights reserved.
//

import Foundation
import UIKit

class SecondViewController: UIViewController {
    
    let dificuldade = UILabel()
    let buttonEasy = UIButton()
    let buttonMedium = UIButton()
    let buttonHard = UIButton()
    let imgBackground = UIImageView()
    let imgView = UIImageView()
    
    override func viewDidLoad() {
        
        let view = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 1440, height: 900))
        view.backgroundColor = .white
        navigationController?.navigationBar.isHidden = true
        
        imgBackground.image = UIImage(imageLiteralResourceName: "Background")
        
        imgView.image = UIImage(imageLiteralResourceName: "Rectangle 10")
        
        dificuldade.frame = CGRect(x: 350, y: 320, width: 928, height: 107)
        dificuldade.text = "Select game difficulty"
        dificuldade.textColor = .black
        
        let font = UIFont(name: "Quicksand-Bold", size: 40)
        dificuldade.font = font
                
        let imageEasy = UIImage(named: "Facil")!
        buttonEasy.setImage(imageEasy, for: .normal)
        
        buttonEasy.addTarget(self, action: #selector(SecondViewController.touchedButtonEasy), for: .touchUpInside)
                
        let imageMedium = UIImage(named: "Medio")!
        buttonMedium.setImage(imageMedium, for: .normal)
        
        buttonMedium.addTarget(self, action: #selector(SecondViewController.touchedButtonMedium), for: .touchUpInside)
                
        let imageHard = UIImage(named: "Dificil")!
        buttonHard.setImage(imageHard, for: .normal)
        
        buttonHard.addTarget(self, action: #selector(SecondViewController.touchedButtonHard), for: .touchUpInside)
        
        view.addSubview(imgBackground)
        view.addSubview(imgView)
        view.addSubview(dificuldade)
        view.addSubview(buttonEasy)
        view.addSubview(buttonMedium)
        view.addSubview(buttonHard)
        self.view = view
        
        imgBackground.translatesAutoresizingMaskIntoConstraints = false
        imgBackground.heightAnchor.constraint(equalTo: self.view.heightAnchor).isActive = true
        imgBackground.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.heightAnchor.constraint(equalToConstant: self.view.frame.height/5).isActive = true
        imgView.widthAnchor.constraint(equalToConstant: self.view.frame.width/2.5).isActive = true
        imgView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        imgView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        buttonEasy.translatesAutoresizingMaskIntoConstraints = false
        buttonEasy.heightAnchor.constraint(equalToConstant: self.view.frame.height/16).isActive = true
        buttonEasy.widthAnchor.constraint(equalToConstant: self.view.frame.width/9).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: buttonEasy, attribute: .bottom, relatedBy: .equal, toItem: imgView, attribute: .bottom, multiplier: 0.88, constant: 0.8))
        self.view.addConstraint(NSLayoutConstraint(item: buttonEasy, attribute: .left, relatedBy: .equal, toItem: imgView, attribute: .left, multiplier: 1.8, constant: 0.8))
        
        buttonMedium.translatesAutoresizingMaskIntoConstraints = false
        buttonMedium.heightAnchor.constraint(equalToConstant: self.view.frame.height/16).isActive = true
        buttonMedium.widthAnchor.constraint(equalToConstant: self.view.frame.width/9).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: buttonMedium, attribute: .bottom, relatedBy: .equal, toItem: imgView, attribute: .bottom, multiplier: 0.88, constant: 0.8))
        self.view.addConstraint(NSLayoutConstraint(item: buttonMedium, attribute: .left, relatedBy: .equal, toItem: imgView, attribute: .left, multiplier: 5.55, constant: 0.8))
        
        buttonHard.translatesAutoresizingMaskIntoConstraints = false
        buttonHard.heightAnchor.constraint(equalToConstant: self.view.frame.height/16).isActive = true
        buttonHard.widthAnchor.constraint(equalToConstant: self.view.frame.width/9).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: buttonHard, attribute: .bottom, relatedBy: .equal, toItem: imgView, attribute: .bottom, multiplier: 0.88, constant: 0.8))
        self.view.addConstraint(NSLayoutConstraint(item: buttonHard, attribute: .left, relatedBy: .equal, toItem: imgView, attribute: .left, multiplier: 9.3, constant: 0.8))
        
        dificuldade.translatesAutoresizingMaskIntoConstraints = false
        dificuldade.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        dificuldade.heightAnchor.constraint(equalToConstant: self.view.frame.height/5).isActive = true
        
        self.view.addConstraint(NSLayoutConstraint(item: dificuldade, attribute: .bottom, relatedBy: .equal, toItem: imgView, attribute: .top, multiplier: 2.4, constant: 0.8))



        
    }
    
    @IBAction func touchedButtonEasy() {
        let vc = ThirdViewController(screenType: .mac, isPortrait: true)
        vc.difficulty = 120
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func touchedButtonMedium() {
        let vc = ThirdViewController(screenType: .mac, isPortrait: true)
        vc.difficulty = 60
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func touchedButtonHard() {
        let vc = ThirdViewController(screenType: .mac, isPortrait: true)
        vc.difficulty = 30
        navigationController?.pushViewController(vc, animated: true)
    }
}
